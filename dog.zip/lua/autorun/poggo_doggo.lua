local function AddPlayerModel( name, model )

    list.Set( "PlayerOptionsModel", name, model )
    player_manager.AddValidModel( name, model )
    player_manager.AddValidHands( "Poggo Doggo", "models/weapons/poggo_doggo_arms.mdl", 0, "00000000" )	
end

AddPlayerModel( "Poggo Doggo", "models/player/poggo_doggo.mdl" )