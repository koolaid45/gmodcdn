//Poggo Doggo

local Category = "YouTube Italia"

local NPC = 
{   
	Name = "Poggo Doggo", 
    Class = "npc_citizen",
	KeyValues = { SquadName = "PoggoTeam", Numgrenades = 5, citizentype = 4 },
		Weapons = { "weapon_smg1" },
    Model = "models/player/poggo_doggo.mdl", 
    Health = "1000", 
	Category = Category
}
                               
list.Set( "NPC", "npc_poggo_doggo_ally", NPC )

local Category = "YouTube Italia"

local NPC = 
{   
	Name = "Poggo Doggo Enemy", 
    Class = "npc_combine_s",
	Weapons = { "weapon_smg1" },
    Model = "models/player/poggo_doggo.mdl", 
    Health = "1000", 
	Category = Category
}
                               
list.Set( "NPC", "npc_poggo_doggo_hostile", NPC )