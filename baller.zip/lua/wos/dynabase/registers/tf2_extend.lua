
wOS.DynaBase:RegisterSource({
    Name = "TF2 Extension",
    Type =  WOS_DYNABASE.EXTENSION,
    Shared = "models/player/wiltos/anim_extension_mod13.mdl",
})

hook.Add( "PreLoadAnimations", "wOS.DynaBase.MountTF2", function( gender )
    if gender != WOS_DYNABASE.SHARED then return end
    IncludeModel( "models/player/wiltos/anim_extension_mod13.mdl" )
end )