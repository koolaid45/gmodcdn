--[[
[b]Lightsaber Hilts[/b]
models/swtor/anzati/lightsabers/lego_lightsaber.mdl
models/swtor/anzati/lightsabers/lego_lightsaber_dual.mdl
models/swtor/anzati/lightsabers/lego_lightsaber_kylo.mdl

[b]Materials[/b]
wos/lightsabers/blades/anzati/lego_blade

[u]ALCS Blade Type[/u]
[i]wos-lightsaberaddon/lua/wos/advswl/lightsaber/blades/default_blades.lua[/i]
wOS.ALCS.LightsaberBase:AddBlade({
	Name = "Lego Blade",
	InnerMaterial = "",
	EnvelopeMaterial = "wos/lightsabers/blades/anzati/lego_blade",
	UseParticle = false,
	DrawTrail = false,
	QuillonParticle = false,
	QuillonInnerMaterial = "",
	QuillonEnvelopeMaterial = "",
})


[u]SWEP[/u]
[i]wos-lightsaberaddon/lua/weapons/yourswep.lua[/i]
SWEP.CustomSettings = 
{
	Blade = "Lego Blade",
}

[u]ITEM CREATION[/u]
[i]wos-lightsaberaddon/lua/wos/advswl/lightsaber/crafting/items/youritem.lua[/i]
wep.CustomSettings.Blade = "Lego Blade"

]]--